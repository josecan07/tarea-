<?php
require_once '../config/db.php';

// Ejemplo de registro de usuario. Ejecuta esto una vez para crear un usuario.
$username = 'usuario1';
$password = password_hash('contraseña123', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
$stmt->execute([$username, $password]);

echo "Usuario registrado";
?>