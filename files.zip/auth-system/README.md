# Sistema de Autenticación PHP + MySQL

## Instrucciones

1. **Configura la base de datos**:  
   Ejecuta el archivo `database.sql` en tu servidor MySQL.

2. **Configura la conexión**:  
   Edita `config/db.php` con tus datos de acceso a MySQL.

3. **Registra usuarios**:  
   Puedes usar el script `includes/auth.php` para registrar un usuario manualmente (ejecuta una sola vez).

4. **Inicia el servidor**:  
   Coloca la carpeta en tu servidor local (XAMPP, MAMP, etc.), accede a `/public/login.php` y prueba el login.

5. **Estructura de carpetas**:  
   - `config/` Conexión a la base de datos  
   - `public/` Archivos accesibles por el usuario  
   - `includes/` Scripts auxiliares  
   - `README.md` Documentación

## Cierre de sesión

Haz click en "Cerrar Sesión" en el dashboard para terminar la sesión.

## Enlace al repositorio

_Agrega aquí tu enlace de GitHub o Bitbucket una vez subido._